﻿--------------------------------------------------------------------------------------------------------------------------------

----------------------------------------
-- 自动换宠列表
-- 
-- 注意:
-- 自动换宠只会换第一个宠物
-- 如果宠物判定为无宠可换, 则会尝试复活
----------------------------------------
local AutoReplacePetInfo = {
	[478] = {               -- 位置1的宠物如果是此BreedID则会进行自动替换判断 (1180:赞达拉袭胫者)
		MinHealth = 500,     -- 位置1的宠物血量低于此数值时会进行替换
		NewBreedID = 478,   -- 要换上的宠物的BreedID
		Ability1 = 420,      -- 为换上的宠物自动设置技能(可以省略)
		Ability2 = 506,
		Ability3 = 508
	},
	[325] = {               -- 位置1的宠物如果是此BreedID则会进行自动替换判断 (1180:赞达拉袭胫者)
		MinHealth = 500,     -- 位置1的宠物血量低于此数值时会进行替换
		NewBreedID = 325,   -- 要换上的宠物的BreedID
		Ability1 = 184,      -- 为换上的宠物自动设置技能(可以省略)
		Ability2 = 190,
		Ability3 = 518
	},
	[557] = {               -- 位置1的宠物如果是此BreedID则会进行自动替换判断 (1180:赞达拉袭胫者)
		MinHealth = 500,     -- 位置1的宠物血量低于此数值时会进行替换
		NewBreedID = 557,   -- 要换上的宠物的BreedID
		Ability1 = 420,      -- 为换上的宠物自动设置技能(可以省略)
		Ability2 = 440,
		Ability3 = 595
	},
	[1326] = {               -- 位置1的宠物如果是此BreedID则会进行自动替换判断 (1180:赞达拉袭胫者)
		MinHealth = 500,     -- 位置1的宠物血量低于此数值时会进行替换
		NewBreedID = 1326,   -- 要换上的宠物的BreedID
		Ability1 = 420,      -- 为换上的宠物自动设置技能(可以省略)
		Ability2 = 506,
		Ability3 = 508
	},
	[1180] = {               -- 位置1的宠物如果是此BreedID则会进行自动替换判断 (1180:赞达拉袭胫者)
		MinHealth = 500,     -- 位置1的宠物血量低于此数值时会进行替换
		NewBreedID = 1180,   -- 要换上的宠物的BreedID
		Ability1 = 921,      -- 为换上的宠物自动设置技能(可以省略)
		Ability2 = 919,
		Ability3 = 917
	},
	[41] = {               -- 位置1的宠物如果是此BreedID则会进行自动替换判断 (1180:赞达拉袭胫者)
		MinHealth = 400,     -- 位置1的宠物血量低于此数值时会进行替换
		NewBreedID = 41,   -- 要换上的宠物的BreedID
		Ability1 = 535,      -- 为换上的宠物自动设置技能(可以省略)
		Ability2 = 492,
		Ability3 = 538
	},
	[459] = {               -- 位置1的宠物如果是此BreedID则会进行自动替换判断 (1180:赞达拉袭胫者)
		MinHealth = 400,     -- 位置1的宠物血量低于此数值时会进行替换
		NewBreedID = 459,   -- 要换上的宠物的BreedID
		Ability1 = 535,      -- 为换上的宠物自动设置技能(可以省略)
		Ability2 = 492,
		Ability3 = 538
	},
	[1266] = {               -- 位置1的宠物如果是此BreedID则会进行自动替换判断 (1180:赞达拉袭胫者)
		MinHealth = 400,     -- 位置1的宠物血量低于此数值时会进行替换
		NewBreedID = 1266,   -- 要换上的宠物的BreedID
		Ability1 = 974,      -- 为换上的宠物自动设置技能(可以省略)
		Ability2 = 1016,
		Ability3 = 536
	},
}

local STATUS_FRAME_SPACING = 4
local STATUS_FRAME_ICON_SIZE = 20
local statusFrame = CreateFrame("Frame", "petStatusFrame")
local extraButton = petModel.ExtraButton

local autoReplacePetEnabled = false
local lastReplacePet
----------------------------------------
-- 状态框初始化函数
----------------------------------------
statusFrame.Initialize = function(self)
	-- 设置状态框
	statusFrame:SetWidth(120)
	statusFrame:SetHeight(160)
	statusFrame:SetPoint("TOPLEFT", 0, -300)
	statusFrame:SetBackdrop({
		bgFile = [[Interface\Tooltips\UI-Tooltip-Background]],
	    edgeFile = [[Interface\Tooltips\UI-Tooltip-Border]],
	    tile = true, tileSize = 8, edgeSize = 8,
	    insets = { left = 1, right = 1, top = 1, bottom = 1 }
	})
	statusFrame:SetBackdropColor(0, 0, 0, 0.8)
	statusFrame:SetBackdropBorderColor(0.8, 0.8, 0.8, 1.0);
	statusFrame:SetMovable(true)
	statusFrame:EnableMouse(true)
	statusFrame:RegisterForDrag("LeftButton")
	statusFrame:SetScript("OnDragStart", function() statusFrame:StartMoving() end)
	statusFrame:SetScript("OnDragStop", function() statusFrame:StopMovingOrSizing() end)

	-- 创建状态文字
	local text1 = statusFrame:CreateFontString(nil, "OVERLAY", "GameTooltipTextSmall")
	text1:SetPoint("TOPLEFT", STATUS_FRAME_SPACING + 2 + STATUS_FRAME_ICON_SIZE, -6)
	statusFrame.text1 = text1


	-- 创建复活宏按钮
	if not extraButton then
		extraButton = CreateFrame("Button","petExtraButton",statusFrame,"SecureActionButtonTemplate")
	end
	-- extraButton:SetWidth(STATUS_FRAME_ICON_SIZE)
	-- extraButton:SetHeight(STATUS_FRAME_ICON_SIZE)
	-- extraButton:SetNormalTexture(select(3,GetSpellInfo(125439)))
	-- extraButton:SetPoint("TOPLEFT", statusFrame:GetName(), "TOPLEFT", 2, -2)

	-- 创建复活CD文字
	statusFrame.reviveCD = extraButton:CreateFontString(nil, "OVERLAY")
	statusFrame.reviveCD:SetPoint("CENTER")
	statusFrame.reviveCD:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
	statusFrame.reviveCD:SetTextColor(1, 0.5, 0, 1)

	statusFrame:SetScript("OnUpdate", function()
		-- 自动更新复活CD
		if statusFrame.reviveCD then
			local s,d = GetSpellCooldown(125439)
			local cd = s+d-GetTime()
			cd = (cd >= 60) and floor(cd/60+0.5).."m" or ceil(cd)
			statusFrame.reviveCD:SetText(s>0 and cd or "")
		end
		-- 战斗结束自动换宠
		if autoReplacePetEnabled and (not C_PetBattles.IsInBattle()) then
			autoReplacePetEnabled = false
			AutoReplacePet(true)
		end
	end)

	-- 修改一键对战按钮宏内容, 在原内容前面增加一行调用代码.
	-- 增加一行代码的好处是: 当原作者修改一键对战按钮宏内容时, 本插件不需要修改
	if petModel.ActionButton then
		local macrotext = petModel.ActionButton:GetAttribute("macrotext") or ""
		macrotext = "/run AutoReplacePet()\n" .. macrotext
		petModel.ActionButton:SetAttribute("type","macro")
		petModel.ActionButton:SetAttribute("macrotext",macrotext)
	end

	statusFrame.Initialize = nil
end

----------------------------------------
-- 更新状态框
----------------------------------------
statusFrame.Update = function(self, remXP, remBattles)
	self.text1:SetText(format("您目前等级:|cff00ff00%d|r 经验:|cff00ff00%.2f%%|r / 升级经验:|cff00ff00%d|r / 再打|cffff8c00%d|r场就升级 。 \n\n|cff00ff00小号升到110级自动隐藏此框 |r。\n\n感谢使用宠物对战，|cffff8c00魔兽交流QQ群：256670662|r（群内分享更多实用工具插件哟~）\n\n插件作者：上官晓雾\n\n插件更新：纯情小黄牛",
		UnitLevel("player"), floor(10000*(UnitXP("player")/UnitXPMax("player"))+0.5)/100, remXP, remBattles))
	self:SetWidth(statusFrame.text1:GetWidth() + STATUS_FRAME_ICON_SIZE + STATUS_FRAME_SPACING * 2 + 2)

	if not self:IsShown() then self:Show() end
end

----------------------------------------
-- 更新 petExtraButton
--
-- 根据需要将按钮内容设置为: 无/复活战斗宠物/战斗宠物绷带
----------------------------------------
local lastBattlePetBandage
statusFrame.UpdateExtraButton = function(self, needRevive, needClick)
-- needClick 参数:
-- 
-- 一键对战宏方式调用:
-- /run AutoReplacePet() -> UpdateExtraButton() -> /pet -> /click petExtraButton
-- 此方式不需要指定 needClick 参数, 因为宏末尾会点击 petExtraButton
-- 
-- PET_BATTLE_CLOSE 事件自动调用:
-- 宠物对战结束时会自动调用 AutoReplacePet(true) -> UpdateExtraButton(true, true)
-- 此方式无法自动点击 petExtraButton, 所以只能自动换宠, 要手动按一键对战热键才能复活.

	if not extraButton then return end
	ActionButton_HideOverlayGlow(extraButton)
	if not needRevive then extraButton:SetAttribute("type1",nil) return end

	local s,d=GetSpellCooldown(125439)        -- 获取复活战斗宠物的CD
	if s > 0 then -- 复活CD
		if GetItemCount(86143, false, false) <= 0 then
			-- print(GetSpellLink(125439).."CD:"..SecondsToTime(s+d-GetTime()),"沒有戰寵繃帶")
			extraButton:SetAttribute("type1",nil)
		else
			if (lastBattlePetBandage or 0) + 5 <= GetTime() then
				-- print(GetSpellLink(125439).."CD:"..SecondsToTime(s+d-GetTime()),"請按一鍵對戰熱鍵使用戰寵繃帶")
				extraButton:SetAttribute("type1","item")
				extraButton:SetAttribute("item1",GetItemInfo(86143))
				lastBattlePetBandage = GetTime()
			else
				-- print(ceil(lastBattlePetBandage + 5 - GetTime()).."秒後使用戰寵繃帶")
				extraButton:SetAttribute("type1",nil)
			end
		end
	else
		if needClick then
		print("宠物都死光光了, 先复活在战斗吧！")
			ActionButton_ShowOverlayGlow(extraButton)
		else
			-- print("復活戰寵")
		end
		extraButton:SetAttribute("type1","spell")
		extraButton:SetAttribute("spell1",GetSpellInfo(125439))
	end
end

----------------------------------------
-- 更新状态框可见性
----------------------------------------
-- local wonBattles
-- local avgTime
-- local lastTime
local lastXP
statusFrame.UpdateVisibility = function(self)

		if self.Initialize then
			self:Initialize()
--			lastTime = GetTime()
			lastXP = UnitXP("player")
			self:Update(UnitXPMax("player") - lastXP, 0)
		end
		if UnitLevel("player") >= 110 then -- 达到90级时隐藏
			self:Hide()
		else
			self:Show()
		end
end

statusFrame:RegisterEvent("ZONE_CHANGED")
statusFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
statusFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
statusFrame:RegisterEvent("MINIMAP_ZONE_CHANGED")
statusFrame:RegisterEvent("PLAYER_ENTERING_WORLD")

statusFrame:SetScript("OnEvent", function(self,event,...)
	statusFrame:UpdateVisibility()
end)

----------------------------------------
-- 经验值改变时计算并更新状态框
----------------------------------------
petModel:AddReg("PLAYER_XP_UPDATE",function(...)
	if not statusFrame:IsShown() then return end

--	local nowTime = GetTime()
	local curXP = UnitXP("player")
	local remXP = UnitXPMax("player") - curXP
	local remBattles = 0

	if lastXP and curXP > lastXP then
		local stepXP = curXP - lastXP
		remBattles = remXP / stepXP
	end


	lastXP = curXP
	statusFrame:Update(remXP, ceil(remBattles))
end)

----------------------------------------
-- 按照特定BreedID找出当前血量最多的战斗宠物
----------------------------------------
local function FindMaxHealthPetByBreedID(breedID, minHP)
	local newHP,newPow,newSpd=minHP or 0,0,0
	local newGuid
	local _,o=C_PetJournal.GetNumPets()
	for i=1,o do
		local petId,specId,_,_,lv=C_PetJournal.GetPetInfoByIndex(i)
		if specId==breedID and lv==25 then
			local h,_,p,s,_=C_PetJournal.GetPetStats(petId)
			if h>newHP then
				newHP=h
				newPow=p
				newSpd=s
				newGuid=petId
			end
		end
	end
	return newGuid,newHP,newPow,newSpd
end

----------------------------------------
-- 自动换宠/复活核心函数
-- 
-- AutoReplacePet 总是 return true, 用意是:
-- 以后有需要时可以改为以下形式:
-- petModel.otherfunc["AutoReplacePet"] = AutoReplacePet
-- 届时将一键对战宏内容中的 /run AutoReplacePet() 改为 /pet AutoReplacePet 即可
-- 即: 第一次  /pet AutoReplacePet 执行战斗外代码, 第二次 /pet 执行战斗内代码
----------------------------------------
function AutoReplacePet(needClick)
	statusFrame:UpdateExtraButton(false, false)

	if C_PetBattles.IsInBattle() then return true end    -- 宠物战斗进行中, 退出函数

	-- 自动解散当前战斗宠物 (避免敌对阵营看到你的宠物)
	local curPetGuid=C_PetJournal.GetSummonedPetGUID()
	if curPetGuid then C_PetJournal.SummonPetByGUID(curPetGuid) end

	-- 取得1号位置的宠物信息
	local petId,a1,a2,a3,l=C_PetJournal.GetPetLoadOutInfo(1)
	local curHP,_,curPow,curSpd,_=C_PetJournal.GetPetStats(petId)
	local specId=select(1,C_PetJournal.GetPetInfoByPetID(petId))

	-- 查询自动换宠信息
	local replaceInfo = AutoReplacePetInfo[specId]

	if not replaceInfo then return true end

	-- 如果设置的技能不对, 则先重设技能
	if replaceInfo.Ability1 and a1~=replaceInfo.Ability1 then
		C_PetJournal.SetAbility(1,1,replaceInfo.Ability1)
		-- print("重设1号技能")
	end
	if replaceInfo.Ability2 and a2~=replaceInfo.Ability2 then
		C_PetJournal.SetAbility(1,2,replaceInfo.Ability2)
		-- print("重设2号技能")
	end
	if replaceInfo.Ability3 and a3~=replaceInfo.Ability3 then
		C_PetJournal.SetAbility(1,3,replaceInfo.Ability3)
		-- print("重设3号技能")
	end

	-- 判断是否需要换宠
	if curHP < replaceInfo.MinHealth then
		-- 下面这行代码使用 curHP (当前宠物剩余血量) 作为血量下限来寻找新的宠物.
		-- 改为 replaceInfo.MinHealth 则使用 AutoReplacePetInfo 表中指定的换宠血量下限.
		-- 区别在于: 如果三只宠物都残血 (低于换宠血量下限) 但没死:
		--  使用 curHP 的结果就是把血量最高那个派上场发挥余热;
		--  使用 replaceInfo.MinHealth 的结果就是无宠可换, 判定为需要复活.
		local newGuid,newHP,newPow,newSpd = FindMaxHealthPetByBreedID(replaceInfo.NewBreedID, curHP)
		if newGuid then
			-- 更换宠物
			C_PetJournal.SetPetLoadOutInfo(1,newGuid)
			-- 设置技能
			if replaceInfo.Ability1 then C_PetJournal.SetAbility(1,1,replaceInfo.Ability1) end
			if replaceInfo.Ability2 then C_PetJournal.SetAbility(1,2,replaceInfo.Ability2) end
			if replaceInfo.Ability3 then C_PetJournal.SetAbility(1,3,replaceInfo.Ability3) end
			-- speciesID, customName, level, xp, maxXp, displayID, isFavorite, name, icon, petType, creatureID, sourceText, description, isWild, canBattle, tradable, unique, obtainable = C_PetJournal.GetPetInfoByPetID("petID")
			-- print(select(8,C_PetJournal.GetPetInfoByPetID(petId)), "("..curHP.."/"..curPow.."/"..curSpd..")",
				-- "更换为",
				-- select(8,C_PetJournal.GetPetInfoByPetID(newGuid)), "("..newHP.."/"..newPow.."/"..newSpd..")")
		else
			-- print(select(8,C_PetJournal.GetPetInfoByPetID(petId)), "("..curHP.."/"..curPow.."/"..curSpd..")", "没有可以更换的宠物")
			statusFrame:UpdateExtraButton(true, needClick)
		end
	end

	return true
end

petModel:AddReg("PET_BATTLE_OPENING_START",function(...)
	autoReplacePetEnabled = false
end)

-- PET_BATTLE_OVER

petModel:AddReg("PET_BATTLE_CLOSE",function(...)
	autoReplacePetEnabled = true
end)

--------------------------------------------------------------------------------------------------------------------------------