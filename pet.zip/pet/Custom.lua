﻿petModel.Custom[1]=function(Self,Enemy)
	--[[这种方式大家随便写,随便写在哪,或者哪个lua文件(新的lua文件,你得在toc里添加名字.)
	petModel.Custom[n],n可以随便命,理论上按数字顺序优先,从0开始,如果是字母,再按大写>小写,
	看懂了,这页面的代码就随便删掉吧(如果不需要的话)

	所以为了无视这些优先级,自己写的代码最好都限定好PetID
	]]

end

petModel.Custom[0]=function(Self,Enemy)
	----这段代码是在被控制的时候处理方法.我默认的是待命.毕竟打PVE不在乎这一回合.若你有更好的想法.就自己删掉
	if (Self.Buff(174) or Self.Buff(498) or Self.Buff(734) or Self.Buff(822) or Self.Buff(927)) or Self.Buff(926) then
		return 0
	end
end


petModel.Custom["Feicui"]=function(Self,Enemy)
	if Enemy.PetID{570,703,566,754,569,567,572,568,571,565,702,753,573,564,699} then --动物水栖飞行
		if Self.PetID{41,491,40,319,459,224,46,43,44,45,42} then --猫
			if Enemy.Buff(284) and Self.Ability(2) then --生存 钻地
				return 2
			end
			if Enemy.Buff(340) and Self.Ability(2) then --生存 钻地
				return 2
			end
			
			if Enemy.Health(500) and Self.Ability(3) then
				return 3
				else
				return 1
			end	
		end
		if Self.PetID(1266) then
			if Enemy.Buff(284) and Self.Ability(3) then --生存 钻地
				return 3
			end
			if Enemy.Buff(340) and Self.Ability(3) then --生存 钻地
				return 3
			end
			
			if Self.Health(400) and Self.Ability(2) then
				return 2
			end
		
			if Enemy.Health(400) and Self.Ability(2) then
				return 2
				else 
				return 1
			end
		end
	end
end

petModel.Custom["xiaoyi"]=function(Self,Enemy)
	------------小艺---------
	-------准备:恐龙+斩杀宠物({1147,325,1061,67,68}) or 恐龙+恐龙+恐龙
	-------过程:2 1 3 丢完。没死，换下一只宠物,斩杀(无法2回合内斩杀，直接认输)or恐龙(重复之前的)
	if Enemy.PetID(1190) then
		if Self.PetID(1180) then
			if Enemy.Health(676) and Self.Ability(3) then ---如果小艺血量低于676,并且技能3血牙没有CD。就用技能3秒杀 
				return 3
			elseif Enemy.Health(200) and Self.Ability(1) then --如果小艺血量低于200，直接用小队，不上buff了。
                return 1
			elseif Self.Ability(3) and Enemy.Health(2800) and Enemy.Buff(542) and Self.Buff(237) then ---如果小艺血量小于2800，且身上有破碎防御debuff和自己有野兽buff，血牙又可以用，那使用技能3血牙秒杀 
				return 3 	
			elseif Self.Ability(3) and Enemy.Health(1352) and Enemy.Buff(542) then ---如果小艺血量小于1352，且身上有破碎防御debuff，血牙又可以用，那使用技能3血牙秒杀 
				return 3 
			elseif Self.Ability(3) and Enemy.Health(845) and Self.Buff(237) then ---如果小艺血量小于845，且自己有野兽buff，血牙又可以用，那使用技能3血牙秒杀 
				return 3 
			end
			
			if not Self.Ability(1) and not Self.Ability(3) then
				if C_PetBattles.CanPetSwapIn(2) then
					return nil,2
				elseif C_PetBattles.CanPetSwapIn(3) then
					return nil,3
				else
					return nil,1
				end
			end
			if not Self.Ability(1) and Self.Ability(3) then
				return 3
			end
			if not Enemy.Buff(918) and Self.Ability(2) then
				return 2
			elseif Self.Ability(1) then
				return 1
			else
				return 2
			end
		end
		
		if Self.PetID{1211,1212} then
			if not Enemy.Buff(918) and Self.Ability(2) then
				return 3
			elseif Self.Ability(1) then
				return 1
			else
				return 2
			end
		end
		
		if Self.PetID(1180) then
			if not Enemy.Buff(918) and Self.Ability(2) then
				return 3
			elseif Self.Ability(1) then
				return 1
			else
				return 2
			end
		end
			
		
		
		--斩杀
		if Self.PetID({1147,325,1061,67,68}) then		------我优化了下SelfPetID函数，用SelfPetID({a,b,c,d})这样的方式。替换SelfPetID(a) or SelfPetID(b)...
			
			if not Self.Ability(3) then
				if C_PetBattles.CanPetSwapIn(2) then
					return nil,2
				elseif C_PetBattles.CanPetSwapIn(3) then
					return nil,3
				else
					return nil,1
				end
			end
			
			if Enemy.Health(4100*0.25+280) and Self.Ability(3) then
				return 3
			else
				return 1
			end		
		end
		
		
		if Self.PetID(518) then --裂蹄小牛
			return 1
		end
		if Self.PetID(532) then --迷你碎角
			return 2
		end
		
		if Self.PetID({557,87}) then  ---虚空精灵龙
			if Self.Health(750) and Self.Ability(2) then
			return 2
			end
			
			if Self.Health(750,true) and Self.Ability(3) then
			return 3
			end
			
			if not Self.Ability(3) and not Self.Ability(2) then
				if C_PetBattles.CanPetSwapIn(2) then
					return nil,2
				elseif C_PetBattles.CanPetSwapIn(3) then
					return nil,3
				else
					return nil,1
				end
			end				
			if Self.Health(750,true) and not Self.Ability(3) then
			return 1
			end
		end	
		
		if Self.PetID(1156) then
		
			if not Self.Ability(3) then
				if C_PetBattles.CanPetSwapIn(2) then
					return nil,2
				elseif C_PetBattles.CanPetSwapIn(3) then
					return nil,3
				else
					return nil,1
				end
			end
			if Self.Health(750) and Self.Ability(3) then
			return 3
			end
			
			if Self.Health(750,true) and Self.Ability(2) then
			return 2
			end
			
			if Self.Ability(1) then
			return 1
			end				
		end		
	end
end

petModel.Custom["Jinxiu"]=function(Self,Enemy)

	if Enemy.PetID{752,751,750,383,749} then --全是水栖
		if Self.PetID{503,1326,498,478,402,464,732,141,139,544,753,138,421,718,140,1039,1324,1325,756,748} then --蛾子
		
			if Enemy.Buff(296) and Self.Ability(2) then --如果对方用抽水了就按2
				return 2
			end 
			if Enemy.Buff(830) and Self.Ability(2) then
				return 2
			end
			
			if Enemy.Buff(505) and Self.Ability(2) then --如果对方用茧就按2
				return 2
			end 
			
			if Enemy.Buff(284) and Self.Ability(2) then --如果对方用茧就按2
				return 2
			end 
			
			if Enemy.Health(350) then
			return 1
			end
			if Enemy.Buff(498) then --如果被昏睡了
				return 1
			end
			
			if Self.Ability(3) then
				return 3
			end
			
			return 1
		end 
		if Self.PetID(325) then ---艳羽卡利鸟
			if Enemy.Health(350) then
			return 1
			end
			if Enemy.Health(600) and Self.Ability(3) then
				return 3
			end			
			return 1
		end 
		
		if Self.PetID{557,87} then --虚空精灵

			
			if Enemy.Buff(830) and Self.Ability(2) then
				return 2
			end
			
			if Enemy.Buff(505) and Self.Ability(2) then --如果对方用茧就按2
				return 2
			end 
			
			if Enemy.Buff(284) and Self.Ability(2) then --如果对方用茧就按2
				return 2
			end
			
			return 1
		end
		
		if Self.PetID(309) then
		
			if Self.Health(300) and Self.Ability(2) then
				return 2
			end
			
			return 1
			
		end
	end
	
	if Enemy.PetID(747) then --飞行
	
		--------------------------------------------
		
		if Self.PetID(309) then
		
			if Self.Health(300) and Self.Ability(2) then
				return 2
			end
			
			return 1
			
		end
	
		if Self.PetID{557,87} then --虚空精灵
				
			if Enemy.Buff(296) and Self.Ability(2) then --如果对方用抽水了就按2
				return 2
			end 
			if Enemy.Buff(830) and Self.Ability(2) then
				return 2
			end
			
			if Enemy.Buff(505) and Self.Ability(2) then --如果对方用茧就按2
				return 2
			end 
			
			if Enemy.Buff(284) and Self.Ability(2) then --如果对方用茧就按2
				return 2
			end

			if Self.Ability(3) and not Enemy.Buff(284) then
				return 3
			end
			
			return 1
		end
		--------------------------------------------
		
		if Self.PetID{503,1326,498,478,402,464,732,141,139,544,753,138,421,718,140,1039,1324,1325,756,748} then --蛾子

		
			if Enemy.Buff(296) and Self.Ability(2) then --如果对方用抽水了就按2
				return 2
			end 
			if Enemy.Buff(830) and Self.Ability(2) then
				return 2
			end
			
			if Enemy.Buff(505) and Self.Ability(2) then --如果对方用茧就按2
				return 2
			end 
			
			if Enemy.Buff(284) and Self.Ability(2) then --如果对方用茧就按2
				return 2
			end 
			
			if Enemy.Health(350) then
			return 1
			end
			if Enemy.Buff(498) then --如果被昏睡了
				return 1
			end
			
			if Self.Ability(3) then
				return 3
			end
			
			return 1
		end 
			if Self.PetID(325) then ---艳羽卡利鸟
				if Enemy.Health(350) then
					return 1
				end
				if Enemy.Health(600) and Self.Ability(3) then
					return 3
				end			
				return 1
			end 
		end	
	end
	
